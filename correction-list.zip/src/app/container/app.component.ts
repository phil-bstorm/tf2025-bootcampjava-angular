import { Component, signal } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = signal('Hello There!')

  changeTitle() {
    // this.title.set("General Kenobi")
    this.title.update((old) => old.replace("!", ""))
  }
}
